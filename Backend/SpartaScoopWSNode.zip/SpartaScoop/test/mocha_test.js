var request = require('request')
    , express = require('express')
    ,assert = require('chai').assert
    ,http = require("http");


describe('http tests', function(){


    it('should be able to login with correct details', function(done) {
        request.post(
            'http://localhost:3000/checklogin',
            { form: { email: 'jay@sjsu.edu',password:'jayy' } },
            function (error, response, body) {
                assert.equal(200, response.statusCode);
                done();
            }
        );
    });


    it('Check afterSignup', function(done) {
        request.post(
            'http://localhost:3000/afterSignup',
            { form: {username:'Jay', email: 'jay@sjsu.com', password:'jay', degree:'Masters', branch:'SE' } },
            function (error, response, body) {
                assert.equal(200, response.statusCode);
                done();
            }
        );
    });

    it('Get all the jobs', function(done) {
        request.post(
            'http://localhost:3000/getAllJobs',
            { form: { } },
            function (error, response, body) {
                assert.equal(200, response.statusCode);
                done();
            }
        );
    });




});


