/**
 * Created by Nitin on 4/28/17.
 */
var mysql = require('./mysql');
var winston = require('winston');

var logger = new (winston.Logger)({
    transports: [
        new (winston.transports.Console)(),
        new (winston.transports.File)({ filename: 'Log.log' })
    ]
});

exports.getAllJobs = function(req,res){
    console.log("In getAllJobs.");

    var getAllJobQuery = "SELECT JOB_ID,JM.JOB_TYPE_ID, JT.JOB_TYPE, JOB_DESCRIPTION, JOB_LOCATION, JOB_CONTACT_EMAIL, JOB_PAY_RATE     FROM SpartaScoop.JOB_MASTER as JM     JOIN SpartaScoop.JOB_TYPES as JT     on JM.JOB_TYPE_ID = JT.JOB_TYPE_ID;";
    console.log("Query:: " + getAllJobQuery);
    logger.log('info', "Query:: " + getAllJobQuery);
    mysql.fetchData(function(err,results) {
        if(err) {
            throw err;
            logger.log('error', err);
        }
        else {
            if(results.length > 0) {
                //logger.log('info', 'Results are loaded for user : '+req.session.userid);
                json_responses = {"statusCode" : 200,
                    "results" : results};

                res.send(json_responses);
            }
            else {
                console.log("No items to display");
                //logger.log('info', 'No items to display for user : '+req.session.userid);
                json_responses = {"statusCode" : 401};
                res.send(json_responses);
            }
        }
    }, getAllJobQuery );
};
