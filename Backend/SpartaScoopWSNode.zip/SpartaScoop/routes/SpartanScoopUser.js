/**
 * Created by Nitin on 4/28/17.
 */
var mysql = require('./mysql');
var bcrypt = require('./bCrypt.js');
var winston = require('winston');

var logger = new (winston.Logger)({
    transports: [
        new (winston.transports.Console)(),
        new (winston.transports.File)({ filename: 'Log.log' })
    ]
});


//Redirects to the homepage
exports.redirectToHome = function(req,res) {
    //Checks before redirecting whether the session is valid
    if(req.session.userid)
    {
        //Set these headers to notify the browser not to maintain any cache for the page being loaded
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        //res.render("homepage",{userid:req.session.userid});
        res.render('products',{validationMessage:'Empty Messgage'});
    }
    else
    {
        res.redirect('/signin');
    }
};


exports.checklogin= function(req,res) {

    console.log("in checklogin");

    var email = req.param("email");
    var password = req.param("password");

    logger.log('info', 'Signin request from: '+ email);
    console.log("email :: " + email);

    if(email != '') {
        var checkLoginQuery = "select EMAIL_ID,PASSWORD from USER_MASTER where EMAIL_ID = '" + email + "';";
        logger.log('info', 'select EMAIL_ID,PASSWORD from USER_MASTER where EMAIL_ID = '+email);
        console.log("Query:: " + checkLoginQuery);

        mysql.fetchData(function(err,results) {
            if(err) {
                throw err;
                logger.log('error','Error of user :'+email+ ' Error: '+err);
            }
            else {
                if(results.length >0) {
                    if (bcrypt.compareSync(password, results[0].PASSWORD)) {

                        console.log("Successful Login");
                        logger.log('info', 'Successful Login for = ' + email + ' EMAIL_ID: ' + results[0].EMAIL_ID);
                        console.log("EMAIL_ID :  " + results[0].EMAIL_ID);
                        //Assigning the session
                        req.session.email = email;
                        req.session.userid = results[0].EMAIL_ID;

                        logger.log('info', "Session Initialized with email : " + req.session.email);
                        console.log("Session Initialized with email : " + req.session.email);

                        logger.log('info', "userid :: " + req.session.userid);
                        console.log("userid :: " + req.session.userid);

                        json_responses = {"statusCode": 200};
                        res.send(json_responses);
                    }

                    else {
                        logger.log('error', "Invalid password for email Id: " + email);
                        console.log("Invalid Login");
                        json_responses = {"statusCode": 401};
                        res.send(json_responses);
                    }
                }
                else{
                    logger.log('error', "Invalid Login for email Id: "+email +' user is not registered.');
                    json_responses = {"statusCode": 401};
                    console.log(json_responses);
                    res.send(json_responses);
                }
            }
        }, checkLoginQuery);
    }
};


exports.afterSignup = function(req,res){// load new user data in database
    console.log("In aftersignup");

    var username = req.param("username");
    var email = req.param("email");
    var password = req.param("password");
    var degree = req.param("degree");
    var branch = req.param("branch");
    var profilePic = req.param("profilePic");


    console.log("username :: " + username);
    console.log("email :: " + email);
    console.log("password :: " + password);
    console.log("degree :: " + degree);
    console.log("branch : " + branch);
    //console.log("profilePic : " + profilePic);


    var hash = bcrypt.hashSync(password);
    logger.log('info', "SignUp for new user: username :: " + username);

    var query = "INSERT INTO USER_MASTER (USER_NAME, EMAIL_ID, PASSWORD) VALUES ('" + username + "','" + email + "','" + hash + "')";
    console.log("Query:: " + query);
    logger.log('info', "Query:: " + query);


    mysql.storeData(query, function(err, result){
        //render on success
        if(!err){
            console.log('Valid SignUp!');
            logger.log('info', "Valid Sign up for: "+ email);
            res.send("true");
        }
        //render or error
        else{
            console.log('Invalid SingUp!');
            logger.log('info', "Invalid Sign up for: "+ email);
            res.send("false");
        }
    });


};

